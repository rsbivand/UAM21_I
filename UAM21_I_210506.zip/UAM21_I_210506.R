
## ---- echo=TRUE--------------------------------------------------------------------------------
needed <- c("mapview", "mapsf", "tmap", "ggplot2", "lme4", "openxlsx", "bdl", "terra", "stars", "sf", "readxl", "rgugik") 

## ----------------------------------------------------------------------------------------------
library(rgugik)
data(voivodeship_names)
class(voivodeship_names)


## ----------------------------------------------------------------------------------------------
head(voivodeship_names)

## ----------------------------------------------------------------------------------------------
str(voivodeship_names)


## ----------------------------------------------------------------------------------------------
TERC <- formatC(seq(2, 32, 2), format="d", width=2, flag="0")
sejmik_size <- c(36, 30, 33, 30, 33, 39, 51, 30, 33, 30, 33, 45, 30, 30, 39, 30)
my_data <- data.frame(TERC=TERC, sejmik_size=sejmik_size)
my_data1 <- merge(voivodeship_names, my_data, by="TERC")
head(my_data1)


## ----------------------------------------------------------------------------------------------
readLines("../data/copied_data.csv", n=2)

## ----------------------------------------------------------------------------------------------
copied_data <- read.csv("../data/copied_data.csv")
str(copied_data)


## ----------------------------------------------------------------------------------------------
a <- gsub("kie", "", my_data1$NAME_PL)
b <- sub(" ", "", gsub("kiego", "", substring(tolower(copied_data$Sejmik), 20)))
(o <- match(a, b))


## ----------------------------------------------------------------------------------------------
my_data2 <- cbind(my_data1, copied_data[o,])
str(my_data2)


## ----------------------------------------------------------------------------------------------
set.seed(1)
zz <- copied_data[sample(nrow(copied_data)),]
head(zz)

## ----------------------------------------------------------------------------------------------
b1 <- sub(" ", "", gsub("kiego", "", substring(tolower(zz$Sejmik), 20)))
(o1 <- match(a, b1))


## ----------------------------------------------------------------------------------------------
zz1 <- cbind(my_data1, zz[o1,])
head(zz1)



## ----------------------------------------------------------------------------------------------
all.equal(my_data2$sejmik_size, my_data2$Liczba.radnych)


## ----------------------------------------------------------------------------------------------
all.equal(zz1$sejmik_size, zz1$Liczba.radnych)


## ----------------------------------------------------------------------------------------------
library(readxl)
wybory18 <- as.data.frame(read_excel("../data/2018-sejmiki-po-wojewвdztwach.xlsx"))
names(wybory18) <- make.names(names(wybory18))
str(wybory18)


## ----------------------------------------------------------------------------------------------
my_data_3 <- merge(x=my_data2, y=wybory18, by.x="NAME_PL", by.y="Województwo")


## ----------------------------------------------------------------------------------------------
library(sf)
drvs <- st_drivers("vector")[, -2]
drvs[order(drvs$name),]


## ----------------------------------------------------------------------------------------------
vv <- st_read("../data/rgugik_vv.gpkg")


## ----------------------------------------------------------------------------------------------
class(vv)


## ----------------------------------------------------------------------------------------------
head(vv)


## ----------------------------------------------------------------------------------------------
library(stars)


## ----------------------------------------------------------------------------------------------
library(terra)


## ---- cache=TRUE-------------------------------------------------------------------------------
library(rgugik)
vv1 <- borders_get(voivodeship_names$NAME_PL)
head(vv1)


## ----------------------------------------------------------------------------------------------
my_data_4 <- merge(vv1, my_data_3, by.x="TERYT", by.y="TERC")
st_geometry(my_data_4)


## ----------------------------------------------------------------------------------------------
GRP_csv <- read.csv2("../data/RACH_3498_CTAB_20210429141300.csv")
dim(GRP_csv)
head(GRP_csv)

## ----------------------------------------------------------------------------------------------
GRP_piv_dane <- as.data.frame(read_excel("../data/RACH_3498_XPIV_20210429142101.xlsx", sheet="DANE"))
dim(GRP_piv_dane)
head(GRP_piv_dane)


## ----------------------------------------------------------------------------------------------
library(bdl)


## ---- cache=TRUE-------------------------------------------------------------------------------
GUSlevels <- as.data.frame(get_levels())
woj_level <- GUSlevels[grep("Woj", GUSlevels$name), "id"]
str(woj_level)


## ---- cache=TRUE-------------------------------------------------------------------------------
(rachunki_reg <- as.data.frame(search_subjects("RACH")))


## ----------------------------------------------------------------------------------------------
(rr_subject <- rachunki_reg[grep("RACH", rachunki_reg$name), "id"])


## ---- cache=TRUE-------------------------------------------------------------------------------
x <- get_subjects(parentId=rr_subject)
(rr_subjects <- as.data.frame(x))


## ----------------------------------------------------------------------------------------------
(rr_target <- unlist(rr_subjects[grep("NUTS 2", rr_subjects$name)[1], "children"]))


## ---- cache=TRUE-------------------------------------------------------------------------------
(rr_vars <- as.data.frame(get_variables(rr_target[1])))


## ----------------------------------------------------------------------------------------------
(rr_var <- rr_vars$id[1])


## ---- cache=TRUE-------------------------------------------------------------------------------
rr_data <- as.data.frame(get_data_by_variable(rr_var, unitLevel = woj_level, year = 2014:2019))


## ----------------------------------------------------------------------------------------------
rr_data$TERC <- substring(rr_data$id, 3, 4)
names(rr_data)[4] <- "PRB"
head(rr_data)


## ----------------------------------------------------------------------------------------------
oo <- reshape(rr_data[, -c(5:8)], v.names="PRB", timevar="year", idvar=c("TERC", "id", "name"), direction="wide")
rr_data_wide <- oo[order(oo$TERC), ]
dim(rr_data_wide)
head(rr_data_wide)


## ----------------------------------------------------------------------------------------------
all.equal(rr_data_wide[, 4:8], GRP_csv[,3:7], check.attributes=FALSE)


## ----------------------------------------------------------------------------------------------
names(my_data_4)

## ----------------------------------------------------------------------------------------------
my_data_5 <- merge(my_data_4, rr_data_wide, by.x="TERYT", by.y="TERC")


## ----------------------------------------------------------------------------------------------
saveRDS(my_data_5, file="my_data_5.rds")
my_data_5a <- readRDS("my_data_5.rds")
all.equal(my_data_5, my_data_5a)


## ----------------------------------------------------------------------------------------------
write.csv(rr_data, file="rr_data.csv", row.names=FALSE)
cat(readLines("rr_data.csv", n=3), "\n")


## ----------------------------------------------------------------------------------------------
summary(lm(Liczba.głosów.ważnych ~ PRB.2018, data=my_data_5))


## ----------------------------------------------------------------------------------------------
sink(file="output.txt")
summary(lm(Liczba.głosów.ważnych ~ PRB.2018, data=my_data_5))
sink()
cat(readLines("output.txt"), sep="\n")


## ----------------------------------------------------------------------------------------------
library(openxlsx)
write.xlsx(rr_data_wide, file="rr_data_wide.xlsx")
all.equal(read_excel("rr_data_wide.xlsx"), rr_data_wide, check.attributes=FALSE)


## ----------------------------------------------------------------------------------------------
st_write(vv1, dsn="vv1.gpkg", append=FALSE)


## ---- echo = TRUE------------------------------------------------------------------------------
methods(as.data.frame)


## ---- echo = TRUE------------------------------------------------------------------------------
data(mtcars)
class(mtcars)
attributes(mtcars)


## ---- echo = TRUE------------------------------------------------------------------------------
(oS <- search())


## ---- echo = TRUE------------------------------------------------------------------------------
library(mgcv)
gm <- gam(formula=mpg ~ s(wt), data=mtcars)
class(gm)
print(gm)


## ---- echo = TRUE------------------------------------------------------------------------------
stats:::print.glm(gm)


## ---- echo = TRUE------------------------------------------------------------------------------
methods(logLik)


## ---- echo = TRUE------------------------------------------------------------------------------
nS <- search()
nS[!(nS %in% oS)]


## ---- echo = TRUE------------------------------------------------------------------------------
d100 <- diag(100)
isS4(d100)
class(d100)
str(d100)
object.size(d100)


## ---- echo = TRUE------------------------------------------------------------------------------
getClass(class(d100))


## ---- echo = TRUE------------------------------------------------------------------------------
library(Matrix)
D100 <- Diagonal(100)
class(D100)
isS4(D100)
str(D100)
object.size(D100)


## ---- echo = TRUE------------------------------------------------------------------------------
getClass(class(D100))


## ---- echo = TRUE------------------------------------------------------------------------------
showMethods(f=coerce, classes=class(D100))


## ---- echo = TRUE------------------------------------------------------------------------------
str(as(D100, "dgeMatrix"))


## ---- echo = TRUE------------------------------------------------------------------------------
library(mgcv)
f <- mpg ~ s(wt)
gm <- gam(formula=f, data=mtcars)
gm1 <- gam(update(f, . ~ - s(wt) + poly(wt, 3)), data=mtcars)
anova(gm, gm1, test="Chisq")


## ---- echo = TRUE------------------------------------------------------------------------------
mtcars$fcyl <- as.factor(mtcars$cyl)
f1 <- update(f, log(.) ~ - s(wt) - 1 + wt + fcyl)
f1
lm(f1, data=mtcars)


## ---- echo = TRUE------------------------------------------------------------------------------
terms(f1)


## ---- echo = TRUE------------------------------------------------------------------------------
head(model.matrix(f1, mtcars))


## ---- echo = TRUE------------------------------------------------------------------------------
model.response(model.frame(f1, mtcars))[1:6]
mtcars$mpg[1:6]
log(mtcars$mpg[1:6])


## ---- echo = TRUE------------------------------------------------------------------------------
library(lme4)
lmm <- lmer(update(f, log(.) ~ poly(wt, 3) | fcyl), mtcars)
fixef(lmm)
ranef(lmm)


## ---- echo = TRUE------------------------------------------------------------------------------
mtcars$fam <- as.factor(mtcars$am)
lm(update(f, log(.) ~ - s(wt) + (fam*fcyl)/wt - 1), mtcars)


## ---- echo = TRUE------------------------------------------------------------------------------
xtabs(~ fam + fcyl, data=mtcars)
row.names(mtcars)[mtcars$am == 1]


## ---- echo = TRUE------------------------------------------------------------------------------
require


## ---- echo = TRUE------------------------------------------------------------------------------
ggplot2 <- "gridExtra"
ggplot2
ggplot2 <- as.character(substitute(ggplot2))
ggplot2
paste0("package:", ggplot2) %in% search()


## ---- echo = TRUE------------------------------------------------------------------------------
subset(mtcars, subset=cyl == 4)


## ---- echo = TRUE------------------------------------------------------------------------------
acyl <- "cyl"
ncyl <- 4
mtcars[mtcars[[acyl]] == ncyl,]


## ---- echo = TRUE------------------------------------------------------------------------------
is.list(mtcars)
mtcars[eval(substitute(cyl == 4), mtcars, parent.frame()), ]


## ---- echo = TRUE------------------------------------------------------------------------------
create_form = function(power){
 rhs = substitute(I(hp^pow), list(pow=power))
 as.formula(paste0("mpg ~ ", deparse(rhs)))
}
list_formulae = Map(create_form, seq(1,6))
  # mapply(create_form, seq(1,6))
llm <- lapply(list_formulae, lm, data=mtcars)
sapply(llm, function(x) summary(x)$sigma)


## ---- echo = TRUE------------------------------------------------------------------------------
(lns <- readLines(pipe("dir")))


## ---- echo = TRUE------------------------------------------------------------------------------
con <- file(lns[3])
readLines(con, n=6L)
close(con)


## ---- echo = TRUE------------------------------------------------------------------------------
cat(system('echo "search()" | R --no-save --vanilla', intern=TRUE)[20:23], sep="\n")


## ---- echo = TRUE------------------------------------------------------------------------------
capabilities()
grSoftVersion()


## ---- echo = TRUE------------------------------------------------------------------------------
jacoby <- read.table("../data/jacoby.txt")
summary(jacoby)


## ---- echo = TRUE------------------------------------------------------------------------------
plot(jacoby$x1)


## ---- echo = TRUE------------------------------------------------------------------------------
plot(jacoby$x1, jacoby$x2)


## ---- echo = TRUE------------------------------------------------------------------------------
plot(x2 ~ x1, data=jacoby)


## ---- echo = TRUE------------------------------------------------------------------------------
plot(x2 ~ x1, data=jacoby, xlab="First vector",
  ylab="Second vector", pch=16, col="#EB811B",
  cex=1.2)


## ---- echo = TRUE------------------------------------------------------------------------------
plot(x2 ~ x1, data=jacoby, xlab="First vector",
  ylab="Second vector", pch=16, col="#EB811B",
  cex=1.2)
abline(v=mean(jacoby$x1), h=mean(jacoby$x2),
  lty=2, lwd=2, col="#EB811B")


## ---- echo = TRUE------------------------------------------------------------------------------
library(lattice)
xyplot(x2 ~ x1, jacoby)


## ---- echo = TRUE------------------------------------------------------------------------------
xyplot(x2 ~ x1, jacoby, panel = function(x, y, ...) {
  panel.xyplot(x, y, ...)  
  panel.abline(h = mean(y), v=mean(x), lty = 2,
    lwd=2, col="#EB811B")  
})


## ---- echo = TRUE------------------------------------------------------------------------------
xyplot(x2 ~ x1, jacoby) +
  latticeExtra::layer(panel.abline(h=mean(y), v=mean(x),
  lty = 2, lwd=2, col="#EB811B"))


## ---- echo = TRUE------------------------------------------------------------------------------
library(ggplot2)
ggplot(jacoby) + geom_point(aes(x=x1, y="")) + xlab("")


## ---- echo = TRUE------------------------------------------------------------------------------
ggplot(jacoby) + geom_point(aes(x1, x2))


## ---- echo = TRUE------------------------------------------------------------------------------
p <- ggplot(jacoby) + geom_point(aes(x1, x2), 
  colour="#EB811B", size=2) + xlab("First vector") +
  ylab("Second vector") +
  theme(legend.position = "none")
p


## ---- echo = TRUE------------------------------------------------------------------------------
p + geom_hline(yintercept=mean(jacoby$x2), 
  colour="#EB811B", linetype=2) +
  geom_vline(xintercept=mean(jacoby$x1),
  colour="#EB811B", linetype=2)


## ---- echo = TRUE------------------------------------------------------------------------------
stripchart(jacoby, pch=1, xlab="Data Values",
  ylab="Variable", main="Scatterchart")


## ---- echo = TRUE------------------------------------------------------------------------------
stripchart(jacoby, method="jitter",
  jitter=0.05, pch=1,
  xlab="Data Values",
  ylab="Variable",
  main="Scatterchart with jittering")


## ---- echo = TRUE------------------------------------------------------------------------------
jacobyS <- stack(jacoby)
str(jacobyS, width=45, strict.width="cut")


## ---- echo = TRUE------------------------------------------------------------------------------
stripplot(ind ~ values, data=jacobyS, jitter.data=TRUE)


## ---- echo = TRUE------------------------------------------------------------------------------
#library(reshape2)
#jacobyS <- melt(jacoby)
p <- ggplot(jacobyS, aes(values, ind))
p + geom_point() + ylab("")


## ---- echo = TRUE------------------------------------------------------------------------------
set.seed(1)
p + geom_point() + ylab("") + 
  geom_jitter(position=position_jitter(0.1))


## ---- echo = TRUE------------------------------------------------------------------------------
boxplot(jacoby)


## ---- echo = TRUE------------------------------------------------------------------------------
bwplot(values ~ ind, data=jacobyS)


## ---- echo = TRUE------------------------------------------------------------------------------
p <- ggplot(jacobyS, aes(ind, values))
p + geom_boxplot() + xlab("")


## ---- echo = TRUE------------------------------------------------------------------------------
oldpar <- par(no.readonly=TRUE)
par(mfrow=c(2,2))
brks <- seq(15,55,by=5)
for (i in 1:4) {
 hist(jacoby[,i], breaks=brks, col="grey85",
 xlab=paste("x", i, ": seq(15, 55, by=5)", sep=""),
 freq=TRUE, main="")
}
par(oldpar)


## ----------------------------------------------------------------------------------------------
oldpar <- par(no.readonly=TRUE)
par(mfrow=c(2,2))
for (i in 1:4) {
 hist(jacoby[,i], breaks=seq(17.5,52.5,by=5), col="grey85",
 xlab=paste("x", i, ": seq(17.5, 52.5, by=5)", sep=""), freq=TRUE, main="")
}
par(oldpar)


## ----------------------------------------------------------------------------------------------
oldpar <- par(no.readonly=TRUE)
par(mfrow=c(2,2))
for (i in 1:4) {
 hist(jacoby[,i], breaks=seq(17.5,52.5,by=2.5), col="grey85",
 xlab=paste("x", i, ": seq(17.5, 52.5, by=2.5)", sep=""), freq=TRUE, main="")
}
par(oldpar)


## ---- echo = TRUE------------------------------------------------------------------------------
histogram(~ values | ind, data=jacobyS,
  breaks=seq(15,55,by=5), type="count",
  index.cond=list(c(3,4,1,2)))


## ---- echo = TRUE------------------------------------------------------------------------------
ggplot(jacobyS, aes(x=values)) + 
  geom_histogram(breaks=seq(15, 55, by=5)) + 
  facet_wrap(~ ind, ncol=2)


## ---- echo = TRUE------------------------------------------------------------------------------
oldpar <- par(no.readonly=TRUE)
par(mfrow=c(2,2))
for (i in 1:4) {
  plot(density(jacoby[,i], bw=1.5), main="",
    xlim=c(15,55), ylim=c(0, 0.15))
  rug(jacoby[,i], ticksize=0.07, lwd=2)
  title(main=paste("Smoothed histogram of x",
    i, sep=""))
}
par(oldpar)


## ---- echo = TRUE------------------------------------------------------------------------------
densityplot(~ values | ind, data=jacobyS, bw=1.5,
  index.cond=list(c(3,4,1,2)))


## ---- echo = TRUE------------------------------------------------------------------------------
ggplot(jacobyS, aes(x=values)) + 
  geom_density(bw=1.5) + geom_rug() +
  facet_wrap(~ ind, ncol=2) + 
  xlim(c(15, 55))


## ---- echo = TRUE------------------------------------------------------------------------------
oldpar <- par(no.readonly=TRUE)
par(mfrow=c(2,2))
for (i in 1:4) {
  plot(ecdf(jacoby[,i]), main="",
    xlim=c(15,55))
  title(main=paste("ECDF of x",
    i, sep=""))
}
par(oldpar)


## ---- echo = TRUE------------------------------------------------------------------------------
library(latticeExtra)
ecdfplot(~ values | ind, data=jacobyS,
  index.cond=list(c(3,4,1,2)))
detach(package:latticeExtra)


## ---- echo = TRUE------------------------------------------------------------------------------
ggplot(jacobyS, aes(x=values)) + 
  stat_ecdf() +
  facet_wrap(~ ind, ncol=2)


## ---- echo = TRUE------------------------------------------------------------------------------
oldpar <- par(no.readonly=TRUE)
par(mfrow=c(2,2))
x <- qunif(ppoints(100))
for (i in 1:4) {
  qqplot(x=x, y=jacoby[,i])
  title(main=paste("Uniform QQ of x",
    i, sep=""))
}
par(oldpar)


## ---- echo = TRUE------------------------------------------------------------------------------
oldpar <- par(no.readonly=TRUE)
par(mfrow=c(2,2))
for (i in 1:4) {
  qqnorm(y=jacoby[,i], xlab="", ylab="",
    ylim=c(15, 55), main="")
  title(main=paste("Normal QQ of x",
    i, sep=""))
}
par(oldpar)


## ---- echo = TRUE------------------------------------------------------------------------------
qqmath(~ values | ind, data=jacobyS,
  distribution=qunif,
  index.cond=list(c(3,4,1,2)))


## ---- echo = TRUE------------------------------------------------------------------------------
qqmath(~ values | ind, data=jacobyS,
  distribution=qnorm,
  index.cond=list(c(3,4,1,2)))


## ---- echo = TRUE------------------------------------------------------------------------------
ggplot(jacobyS, aes(sample=values)) + 
  stat_qq(distribution=qunif) +
  facet_wrap(~ ind, ncol=2)


## ---- echo = TRUE------------------------------------------------------------------------------
ggplot(jacobyS, aes(sample=values)) + 
  stat_qq(distribution=qnorm) +
  facet_wrap(~ ind, ncol=2)


## ----------------------------------------------------------------------------------------------
plot(st_geometry(my_data_5))


## ----------------------------------------------------------------------------------------------
library(tmap)
(map_out <-  tm_shape(my_data_5) + tm_borders(col="grey"))


## ----------------------------------------------------------------------------------------------
all(st_is_valid(st_geometry(my_data_5)))


## ----------------------------------------------------------------------------------------------
my_data_5b <- st_make_valid(my_data_5)


## ----------------------------------------------------------------------------------------------
tmap_mode("view")
tm_shape(my_data_5b) + tm_borders()


## ----------------------------------------------------------------------------------------------
tmap_mode("plot")
map_out + tm_text("NAME_PL", remove.overlap=TRUE)


## ----------------------------------------------------------------------------------------------
library(mapsf)
mf_map(my_data_5b)
mf_label(my_data_5b, "NAME_PL", halo=TRUE, r=0.1)


## ---- eval=FALSE-------------------------------------------------------------------------------
## library(mapview)
## mapviewOptions(fgb = FALSE)
## mapview(my_data_5b)


## ----sI, echo = TRUE---------------------------------------------------------------------------
sessionInfo()

