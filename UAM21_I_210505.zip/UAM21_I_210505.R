
## ---- echo=TRUE--------------------------------------------------------------------------------
needed <- c("zoo")


## ----calc2, echo = TRUE------------------------------------------------------------------------
2+3
7*8
3^2
log(1)
log10(10)


## ----calc1, echo = TRUE------------------------------------------------------------------------
print(2+3)
print(sqrt(2))
print(sqrt(2), digits=10)
print(10^7)


## ----calc3, echo = TRUE------------------------------------------------------------------------
log(0)
sqrt(-1)
1/0
0/0


## ----ass1, echo = TRUE-------------------------------------------------------------------------
a <- 2+3
a
is.finite(a)
a <- log(0)
is.finite(a)


## ----vect1, echo = TRUE------------------------------------------------------------------------
a <- c(2, 3)
a
sum(a)
str(a)
aa <- rep(a, 50)
aa


## ----vect2, echo = TRUE------------------------------------------------------------------------
length(aa)
aa[1:10]
sum(aa)
sum(aa[1:10])
sum(aa[-(11:length(aa))])


## ----vect2a, echo = TRUE-----------------------------------------------------------------------
a[1] + a[2]
sum(a)
`+`(a[1], a[2])
Reduce(`+`, a)


## ----vect3, echo = TRUE------------------------------------------------------------------------
sum(aa)
sum(aa+2)
sum(aa)+2
sum(aa*2)
sum(aa)*2


## ----vect4, echo = TRUE------------------------------------------------------------------------
v5 <- 1:5
v2 <- c(5, 10)
v5 * v2
v2_stretch <- rep(v2, length.out=length(v5))
v2_stretch
v5 * v2_stretch


## ----NA, echo = TRUE---------------------------------------------------------------------------
anyNA(aa)
is.na(aa) <- 5
aa[1:10]
anyNA(aa)
sum(aa)
sum(aa, na.rm=TRUE)


## ----check1, echo = TRUE-----------------------------------------------------------------------
big <- 1:(10^5)
length(big)
head(big)
str(big)
summary(big)


## ----coerce1, echo = TRUE----------------------------------------------------------------------
set.seed(1)
x <- runif(50, 1, 10)
is.numeric(x)
y <- rpois(50, lambda=6)
is.numeric(y)
is.integer(y)
xy <- x < y
is.logical(xy)


## ----coerce2, echo = TRUE----------------------------------------------------------------------
str(as.integer(xy))
str(as.numeric(y))
str(as.character(y))
str(as.integer(x))


## ----factor1, echo = TRUE----------------------------------------------------------------------
gen <- c("female", "male", NA)
fgen <- factor(gen)
str(fgen)
nlevels(fgen)
levels(fgen)
as.integer(fgen)
levels(fgen)[as.integer(fgen)]


## ----factor2, echo = TRUE----------------------------------------------------------------------
status <- c("Lo", "Hi", "Med", "Med", "Hi")
ordered.status <- ordered(status, levels=c("Lo", "Med", "Hi"))
ordered.status
str(ordered.status)
table(status)
table(ordered.status)


## ---- echo = TRUE------------------------------------------------------------------------------
strsplit(Sys.getlocale(), ";")


## ---- echo = TRUE------------------------------------------------------------------------------
V5 <- c("ł", "ę", "ą", "Ł")
sapply(V5, charToRaw)
V6 <- iconv(V5, to="CP1250")
sapply(V6, charToRaw)


## ---- echo = TRUE------------------------------------------------------------------------------
now <- Sys.time()
now
class(now)
as.Date(now)
unclass(now)


## ---- echo = TRUE------------------------------------------------------------------------------
str(unclass(as.POSIXlt(now)))


## ---- echo = TRUE------------------------------------------------------------------------------
suppressMessages(library(zoo))
as.yearmon(now)
as.yearqtr(now)
as.Date("2016-03-01") - 1 # day
as.Date("2018-03-01") - 1 # day


## ---- echo = TRUE------------------------------------------------------------------------------
seq(as.Date(now), as.Date(now)+12, length.out=4)


## ---- echo = TRUE------------------------------------------------------------------------------
str(Titanic)


## ---- echo = TRUE------------------------------------------------------------------------------
library(MASS)
data(deaths)
str(deaths)


## ---- echo = TRUE------------------------------------------------------------------------------
V1 <- 1:3
V2 <- letters[1:3]
V3 <- sqrt(V1)
V4 <- sqrt(as.complex(-V1))
L <- list(v1=V1, v2=V2, v3=V3, v4=V4)


## ---- echo = TRUE------------------------------------------------------------------------------
str(L)
L$v3[2]
L[[3]][2]


## ---- echo = TRUE------------------------------------------------------------------------------
DF <- as.data.frame(L)
str(DF)
DF <- as.data.frame(L, stringsAsFactors=FALSE)
str(DF)


## ---- echo = TRUE------------------------------------------------------------------------------
V2a <- letters[1:4]
V4a <- factor(V2a)
La <- list(v1=V1, v2=V2a, v3=V3, v4=V4a)
DFa <- try(as.data.frame(La, stringsAsFactors=FALSE), silent=TRUE)
message(DFa)


## ---- echo = TRUE------------------------------------------------------------------------------
DF$v3[2]
DF[[3]][2]
DF[["v3"]][2]


## ---- echo = TRUE------------------------------------------------------------------------------
DF[2, 3]
DF[2, "v3"]
str(DF[2, 3])
str(DF[2, 3, drop=FALSE])


## ---- echo = TRUE------------------------------------------------------------------------------
as.matrix(DF)
as.matrix(DF[,c(1,3)])


## ---- echo = TRUE------------------------------------------------------------------------------
length(L)
length(DF)
length(as.matrix(DF))


## ---- echo = TRUE------------------------------------------------------------------------------
dim(L)
dim(DF)
dim(as.matrix(DF))


## ---- echo = TRUE------------------------------------------------------------------------------
str(as.matrix(DF))


## ---- echo = TRUE------------------------------------------------------------------------------
row.names(DF)
names(DF)
names(DF) <- LETTERS[1:4]
names(DF)
str(dimnames(as.matrix(DF)))


## ---- echo = TRUE------------------------------------------------------------------------------
str(attributes(DF))
str(attributes(as.matrix(DF)))


## ---- echo = TRUE------------------------------------------------------------------------------
V1a <- c(V1, NA)
V3a <- sqrt(V1a)
La <- list(v1=V1a, v2=V2a, v3=V3a, v4=V4a)
DFa <- as.data.frame(La, stringsAsFactors=FALSE)
str(DFa)


## ---- echo = TRUE------------------------------------------------------------------------------
La <- list(v1=V1a, v2=V2a, v3=V3a, v4=V4a, v5=V5, v6=V6)
DFa <- as.data.frame(La)
str(DFa)


## ----sI, echo = TRUE---------------------------------------------------------------------------
sessionInfo()

