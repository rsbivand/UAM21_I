
## ----set-options-cdn, echo=TRUE, results='hide'------------------------------------------------
td <- tempfile()
dir.create(td)
Sys.setenv("PROJ_USER_WRITABLE_DIRECTORY"=td)
#Sys.setenv("PROJ_NETWORK"="ON")
options("rgdal_show_exportToProj4_warnings"="none")


## ---- echo=TRUE--------------------------------------------------------------------------------
needed <- c("RSQLite", "rgdal", "units", "gdistance", "igraph", "stars", "raster", 
"terra", "sp", "mapview", "ggplot2", "mapsf", "tmap", "colorspace", "RColorBrewer", 
"sf", "classInt")

## ---- echo=TRUE--------------------------------------------------------------------------------
library(classInt)
args(classIntervals)


## ---- echo=TRUE--------------------------------------------------------------------------------
library(sf)
olinda_sirgas2000 <- st_read("olinda_sirgas2000.gpkg")
(cI <- classIntervals(olinda_sirgas2000$DEPRIV, n=7, style="fisher"))


## ---- echo = TRUE, eval=TRUE-------------------------------------------------------------------
Sys.setenv("PROJ_NETWORK"="OFF")
sf_proj_network()
list.files(sf_proj_search_paths()[1])
sf_extSoftVersion()


## ---- echo=TRUE--------------------------------------------------------------------------------
library(RColorBrewer)
pal <- RColorBrewer::brewer.pal((length(cI$brks)-1), "Reds")
plot(cI, pal)


## ---- echo=TRUE--------------------------------------------------------------------------------
display.brewer.all()


## ---- echo=TRUE--------------------------------------------------------------------------------
library(colorspace)
hcl_palettes("sequential (single-hue)", n = 7, plot = TRUE)


## ---- echo=TRUE, eval=FALSE--------------------------------------------------------------------
## pal <- hclwizard()
## pal(6)


## ---- echo=TRUE--------------------------------------------------------------------------------
wheel <- function(col, radius = 1, ...)
  pie(rep(1, length(col)), col = col, radius = radius, ...) 
opar <- par(mfrow=c(1,2))
wheel(rainbow_hcl(12))
wheel(rainbow(12))
par(opar)


## ---- echo=TRUE--------------------------------------------------------------------------------
plot(olinda_sirgas2000[,"DEPRIV"], breaks=cI$brks, pal=pal)


## ---- echo=TRUE--------------------------------------------------------------------------------
plot(olinda_sirgas2000[,"DEPRIV"], nbreaks=7, breaks="fisher", pal=pal)


## ---- echo=TRUE--------------------------------------------------------------------------------
library(tmap)
tmap_mode("plot")
o <- tm_shape(olinda_sirgas2000) + tm_fill("DEPRIV", style="fisher", n=7, palette="Reds")
class(o)


## ---- echo=TRUE--------------------------------------------------------------------------------
o


## ---- echo=TRUE--------------------------------------------------------------------------------
o + tm_borders(alpha=0.5, lwd=0.5)


## ---- echo=TRUE, eval=FALSE--------------------------------------------------------------------
## tmaptools::palette_explorer()


## ---- echo=TRUE--------------------------------------------------------------------------------
library(mapsf)
cols <- mf_get_pal(n = c(5, 5), pal = c("Reds 2", "Greens"))
plot(1:10, rep(1, 10), bg = cols, pch = 22, cex = 4, axes=FALSE, ann=FALSE)


## ---- echo=TRUE--------------------------------------------------------------------------------
mf_choro(olinda_sirgas2000, var="DEPRIV", breaks="fisher", nbreaks=7, pal=pal, leg_val_rnd=3)


## ---- echo=TRUE--------------------------------------------------------------------------------
library(ggplot2)


## ---- echo=TRUE--------------------------------------------------------------------------------
g <- ggplot(olinda_sirgas2000) + geom_sf(aes(fill=DEPRIV))
g


## ---- echo=TRUE--------------------------------------------------------------------------------
g + theme_void()


## ---- echo=TRUE--------------------------------------------------------------------------------
g + theme_void() + scale_fill_distiller(palette="Reds", direction=1)


## ---- echo=TRUE--------------------------------------------------------------------------------
tmap_mode("view")


## ---- echo=TRUE--------------------------------------------------------------------------------
o + tm_borders(alpha=0.5, lwd=0.5)


## ---- echo=TRUE--------------------------------------------------------------------------------
tmap_mode("plot")


## ---- echo=TRUE--------------------------------------------------------------------------------
library(mapview)
if (sf:::CPL_gdal_version() >= "3.1.0") mapviewOptions(fgb = FALSE)
mapview(olinda_sirgas2000, zcol="DEPRIV", col.regions=pal, at=cI$brks)


## ---- echo=TRUE--------------------------------------------------------------------------------
data("pol_pres15", package = "spDataLarge")
pol_pres15 <- st_buffer(pol_pres15, dist=0)


## ---- echo=TRUE--------------------------------------------------------------------------------
library(tmap)
o <- tm_shape(pol_pres15) + tm_facets(free.scales=FALSE) + tm_borders(lwd=0.5, alpha=0.4) + tm_layout(panel.labels=c("Duda", "Komorowski"))


## ---- echo=TRUE, cache=TRUE--------------------------------------------------------------------
o + tm_fill(c("I_Duda_share", "I_Komorowski_share"), n=6, style="pretty", title="I round\nshare of votes")


## ---- echo=TRUE, cache=TRUE--------------------------------------------------------------------
o + tm_fill(c("II_Duda_share", "II_Komorowski_share"), n=6, style="pretty", title="II round\nshare of votes")


## ---- echo = TRUE------------------------------------------------------------------------------
suppressPackageStartupMessages(library(osmdata))
library(sf)


## ---- cache=TRUE, echo = TRUE------------------------------------------------------------------
bbox <- opq(bbox = 'bergen norway')
byb0 <- osmdata_sf(add_osm_feature(bbox, key = 'railway',
  value = 'light_rail'))$osm_lines
tram <- osmdata_sf(add_osm_feature(bbox, key = 'railway',
  value = 'tram'))$osm_lines
byb1 <- tram[!is.na(tram$name),]
o <- intersect(names(byb0), names(byb1))
byb <- rbind(byb0[,o], byb1[,o])
saveRDS(byb, file="byb.rds")


## ---- echo = TRUE------------------------------------------------------------------------------
byb <- readRDS("byb.rds")
library(mapview)
mapviewOptions(fgb = FALSE)
mapview(byb)


## ---- echo = TRUE------------------------------------------------------------------------------
library(sp)
byb_sp <- as(byb, "Spatial")
str(byb_sp, max.level=2)


## ---- echo = TRUE------------------------------------------------------------------------------
str(slot(byb_sp, "lines")[[1]])


## ---- echo = TRUE------------------------------------------------------------------------------
library(terra)
(byb_sv <- as(byb, "SpatVector"))
str(byb_sv)

## ---- echo = TRUE------------------------------------------------------------------------------
geomtype(byb_sv)
str(geom(byb_sv))


## ---- echo = TRUE, eval=FALSE------------------------------------------------------------------
## library(elevatr)
## elevation <- get_elev_raster(byb_sp, z = 10)
## is.na(elevation) <- elevation < 1
## saveRDS(elevation, file="elevation.rds")


## ---- echo = TRUE------------------------------------------------------------------------------
library(raster)
(elevation <- readRDS("elevation.rds"))
str(elevation, max.level=2)


## ---- echo=TRUE--------------------------------------------------------------------------------
str(slot(elevation, "data"))


## ---- echo=TRUE--------------------------------------------------------------------------------
str(as(elevation, "SpatialGridDataFrame"), max.level=2)


## ---- echo = TRUE, eval=TRUE, cache=TRUE-------------------------------------------------------
mapview(elevation, col=terrain.colors)


## ---- echo = TRUE------------------------------------------------------------------------------
(elevation_sr <- as(elevation, "SpatRaster"))
str(elevation_sr)


## ---- echo = TRUE------------------------------------------------------------------------------
str(values(elevation_sr))


## ---- echo = TRUE------------------------------------------------------------------------------
V1 <- 1:3
V2 <- letters[1:3]
V3 <- sqrt(V1)
V4 <- sqrt(as.complex(-V1))
L <- list(v1=V1, v2=V2, v3=V3, v4=V4)


## ---- echo = TRUE------------------------------------------------------------------------------
str(L)
L$v3[2]
L[[3]][2]


## ---- echo = TRUE------------------------------------------------------------------------------
DF <- as.data.frame(L)
str(DF)
DF <- as.data.frame(L, stringsAsFactors=FALSE)
str(DF)


## ---- echo = TRUE------------------------------------------------------------------------------
V2a <- letters[1:4]
V4a <- factor(V2a)
La <- list(v1=V1, v2=V2a, v3=V3, v4=V4a)
DFa <- try(as.data.frame(La, stringsAsFactors=FALSE), silent=TRUE)
message(DFa)


## ---- echo = TRUE------------------------------------------------------------------------------
DF$v3[2]
DF[[3]][2]
DF[["v3"]][2]


## ---- echo = TRUE------------------------------------------------------------------------------
DF[2, 3]
DF[2, "v3"]
str(DF[2, 3])
str(DF[2, 3, drop=FALSE])


## ---- echo = TRUE------------------------------------------------------------------------------
as.matrix(DF)
as.matrix(DF[,c(1,3)])


## ---- echo = TRUE------------------------------------------------------------------------------
length(L)
length(DF)
length(as.matrix(DF))


## ---- echo = TRUE------------------------------------------------------------------------------
dim(L)
dim(DF)
dim(as.matrix(DF))


## ---- echo = TRUE------------------------------------------------------------------------------
str(as.matrix(DF))


## ---- echo = TRUE------------------------------------------------------------------------------
row.names(DF)
names(DF)
names(DF) <- LETTERS[1:4]
names(DF)
str(dimnames(as.matrix(DF)))


## ---- echo = TRUE------------------------------------------------------------------------------
str(attributes(DF))
str(attributes(as.matrix(DF)))


## ---- echo = TRUE------------------------------------------------------------------------------
V1a <- c(V1, NA)
V3a <- sqrt(V1a)
La <- list(v1=V1a, v2=V2a, v3=V3a, v4=V4a)
DFa <- as.data.frame(La, stringsAsFactors=FALSE)
str(DFa)


## ---- echo = TRUE------------------------------------------------------------------------------
DF$E <- list(d=1, e="1", f=TRUE)
str(DF)


## ---- echo = TRUE------------------------------------------------------------------------------
pt1 <- st_point(c(1,3))
pt2 <- pt1 + 1
pt3 <- pt2 + 1
str(pt3)


## ---- echo = TRUE------------------------------------------------------------------------------
st_as_text(pt3)


## ---- echo = TRUE------------------------------------------------------------------------------
st_as_binary(pt3)


## ---- echo = TRUE------------------------------------------------------------------------------
pt_sfc <- st_as_sfc(list(pt1, pt2, pt3))
str(pt_sfc)


## ---- echo = TRUE------------------------------------------------------------------------------
st_geometry(DF) <- pt_sfc
(DF)


## ---- echo = TRUE------------------------------------------------------------------------------
(buf_DF <- st_buffer(DF, dist=0.3))


## ---- echo = TRUE------------------------------------------------------------------------------
library(stars)
fn <- system.file("tif/L7_ETMs.tif", package = "stars")
L7 <- read_stars(fn)
L7


## ---- echo = TRUE------------------------------------------------------------------------------
(L7_R <- as(L7, "Raster"))
(as(L7_R, "SpatRaster"))


## ---- echo = TRUE------------------------------------------------------------------------------
ndvi <- function(x) (x[4] - x[3])/(x[4] + x[3])
(s2.ndvi <- st_apply(L7, c("x", "y"), ndvi))


## ---- echo = TRUE------------------------------------------------------------------------------
L7p <- read_stars(fn, proxy=TRUE)
L7p


## ---- echo = TRUE------------------------------------------------------------------------------
(L7p.ndvi = st_apply(L7p, c("x", "y"), ndvi))


## ---- echo = TRUE------------------------------------------------------------------------------
(x6 <- split(L7, "band"))


## ---- echo = TRUE------------------------------------------------------------------------------
x6$mean <- (x6[[1]] + x6[[2]] + x6[[3]] + x6[[4]] + x6[[5]] +
              x6[[6]])/6
xm <- st_apply(L7, c("x", "y"), mean)
all.equal(xm[[1]], x6$mean)


## ----------------------------------------------------------------------------------------------
byb <- readRDS("byb.rds")
names(attributes(byb))


## ----------------------------------------------------------------------------------------------
library(sf)
st_agr(byb)


## ----------------------------------------------------------------------------------------------
byb$length <- st_length(byb)
summary(byb$length)


## ----------------------------------------------------------------------------------------------
str(byb$length)


## ---- echo=TRUE--------------------------------------------------------------------------------
library(sf)
bbo <- st_read("snow/bbo.gpkg")


## ---- echo=TRUE, warning=FALSE-----------------------------------------------------------------
buildings <- st_read("snow/buildings.gpkg", quiet=TRUE)
deaths <- st_read("snow/deaths.gpkg", quiet=TRUE)
sum(deaths$Num_Css)
b_pump <- st_read("snow/b_pump.gpkg", quiet=TRUE)
nb_pump <- st_read("snow/nb_pump.gpkg", quiet=TRUE)


## ---- echo=TRUE, warning=FALSE-----------------------------------------------------------------
library(sf)
st_crs(buildings) <- st_crs(bbo)
buildings1 <- st_intersection(buildings, bbo)
buildings2 <- st_buffer(buildings1, dist=-4)


## ---- echo=TRUE, warning=FALSE-----------------------------------------------------------------
plot(st_geometry(buildings2))


## ---- echo=TRUE--------------------------------------------------------------------------------
library(raster)
resolution <- 1
r <- raster(extent(buildings2), resolution=resolution, crs=st_crs(bbo)$proj4string)
r[] <- resolution
summary(r)


## ---- echo=TRUE, cache=TRUE, warning=FALSE-----------------------------------------------------
buildings3 <- as(buildings2[!st_is_empty(buildings2),], "Spatial")
cfp <- cellFromPolygon(r, buildings3)
is.na(r[]) <- unlist(cfp)
summary(r)


## ---- echo=TRUE, warning=FALSE-----------------------------------------------------------------
plot(r)


## ---- echo=TRUE, warning=FALSE, message=FALSE--------------------------------------------------
library(gdistance)


## ---- echo=TRUE, cache=TRUE--------------------------------------------------------------------
tr1 <- transition(r, transitionFunction=function(x) 1/mean(x), directions=8, symm=TRUE)


## ---- echo=TRUE, cache=TRUE, warning=FALSE-----------------------------------------------------
sp_deaths <- as(deaths, "Spatial")
d_b_pump <- st_length(st_as_sfc(shortestPath(tr1, as(b_pump, "Spatial"), sp_deaths, output="SpatialLines")))


## ---- echo=TRUE, cache=TRUE, warning=FALSE-----------------------------------------------------
res <- matrix(NA, ncol=nrow(nb_pump), nrow=nrow(deaths))
sp_nb_pump <- as(nb_pump, "Spatial")
for (i in 1:nrow(nb_pump)) res[,i] <- st_length(st_as_sfc(shortestPath(tr1, sp_nb_pump[i,], sp_deaths, output="SpatialLines")))
d_nb_pump <- apply(res, 1, min)


## ---- echo=TRUE--------------------------------------------------------------------------------
library(units)
units(d_nb_pump) <- "m"
deaths$b_nearer <- d_b_pump < d_nb_pump
by(deaths$Num_Css, deaths$b_nearer, sum)


## ----------------------------------------------------------------------------------------------
library(sp)
library(rgdal)
rgdal_extSoftVersion()
projInfo("ellps")


## ----------------------------------------------------------------------------------------------
data("GridsDatums")
GridsDatums[grep("Poland", GridsDatums$country),]


## ----------------------------------------------------------------------------------------------
EPSG <- make_EPSG()
EPSG[grep("Poland", EPSG$note), 1:2]
EPSG[grep("GUGiK", EPSG$note), 1:2]
EPSG[grep("PL", EPSG$note), 1:2]


## ----------------------------------------------------------------------------------------------
st_crs(2180)


## ----------------------------------------------------------------------------------------------
getClass("CRS")


## ----------------------------------------------------------------------------------------------
st_crs(4326)


## ---- echo = TRUE------------------------------------------------------------------------------
ellps <- sf_proj_info("ellps")
(clrk66 <- unlist(ellps[ellps$name=="clrk66",]))


## ---- echo = TRUE------------------------------------------------------------------------------
eval(parse(text=clrk66["major"]))
eval(parse(text=clrk66["ell"]))
print(sqrt((a^2-b^2)/a^2), digits=10)


## ---- echo = TRUE------------------------------------------------------------------------------
sf_proj_search_paths()


## ---- echo = TRUE------------------------------------------------------------------------------
library(RSQLite)
DB0 <- sf_proj_search_paths()
DB <- file.path(DB0[length(DB0)], "proj.db")
db <- dbConnect(SQLite(), dbname=DB)
cat(strwrap(paste(dbListTables(db), collapse=", ")), sep="\n")
dbDisconnect(db)


## ---- echo = TRUE, eval=TRUE-------------------------------------------------------------------
bp_file <- system.file("gpkg/b_pump.gpkg", package="sf")
b_pump_sf <- st_read(bp_file)


## ---- echo = TRUE, eval=TRUE-------------------------------------------------------------------
proj5 <- paste0("+proj=tmerc +lat_0=49 +lon_0=-2 +k=0.9996012717",
 " +x_0=400000 +y_0=-100000 +datum=OSGB36 +units=m +no_defs")
legacy <- st_crs(proj5)
proj6 <- legacy$proj4string
proj5_parts <- unlist(strsplit(proj5, " "))
proj6_parts <- unlist(strsplit(proj6, " "))
proj5_parts[!is.element(proj5_parts, proj6_parts)]
proj6_parts[!is.element(proj6_parts, proj5_parts)]


## ---- echo = TRUE, eval=TRUE-------------------------------------------------------------------
b_pump_sf1 <- b_pump_sf
st_crs(b_pump_sf1) <- st_crs(st_crs(b_pump_sf1)$proj4string)


## ---- echo = TRUE, eval=TRUE-------------------------------------------------------------------
Sys.setenv("PROJ_NETWORK"="OFF")
sf_proj_network(FALSE)
list.files(sf_proj_search_paths()[1])
b_pump_sf_ll <- st_transform(b_pump_sf, "OGC:CRS84")
list.files(sf_proj_search_paths()[1])
b_pump_sf1_ll <- st_transform(b_pump_sf1, "OGC:CRS84")
list.files(sf_proj_search_paths()[1])
sf_use_s2(FALSE)
st_distance(b_pump_sf_ll, b_pump_sf1_ll)


## ---- echo = TRUE, eval=TRUE-------------------------------------------------------------------
library(mapview)
if (sf:::CPL_gdal_version() >= "3.1.0") mapviewOptions(fgb = FALSE)
pts <- rbind(b_pump_sf_ll, b_pump_sf1_ll)
pts$CRS <- c("original", "degraded")
mapview(pts, zcol="CRS", map.type="OpenStreetMap", col.regions=c("green", "red"), cex=18)


## ---- echo = TRUE, eval=TRUE-------------------------------------------------------------------
st_crs("EPSG:4326")


## ---- echo = TRUE, eval=TRUE-------------------------------------------------------------------
library(sp)
cat(wkt(CRS("EPSG:4326")), "\n")


## ---- echo = TRUE, eval=TRUE-------------------------------------------------------------------
sf_from_sp <- st_crs(CRS("EPSG:4326"))
o <- strsplit(sf_from_sp$wkt, "\n")[[1]]
cat(paste(o[grep("CS|AXIS|ORDER", o)], collapse="\n"))


## ---- echo = TRUE, eval=TRUE-------------------------------------------------------------------
sp_from_sf <- as(st_crs("EPSG:4326"), "CRS")
o <- strsplit(wkt(sp_from_sf), "\n")[[1]]
cat(paste(o[grep("CS|AXIS|ORDER", o)], collapse="\n"))


## ---- echo = TRUE, eval=TRUE-------------------------------------------------------------------
cat(st_crs("OGC:CRS:84")$wkt, "\n")


## ---- echo = TRUE, eval=TRUE-------------------------------------------------------------------
cat(wkt(CRS("OGC:CRS84")), "\n")


## ---- echo = TRUE, eval=TRUE-------------------------------------------------------------------
(o <- sf_proj_pipelines(st_crs(b_pump_sf), "OGC:CRS84"))


## ----------------------------------------------------------------------------------------------
as.data.frame(o)[,c(5,8)]


## ---- echo = TRUE, eval=TRUE-------------------------------------------------------------------
aoi0 <- sf_project(st_crs(b_pump_sf), "OGC:CRS84", matrix(unclass(st_bbox(b_pump_sf)), 2, 2, byrow=TRUE))
aoi <- c(t(aoi0 + c(-0.1, +0.1)))
(o_aoi <- sf_proj_pipelines(st_crs(b_pump_sf), "OGC:CRS84", AOI=aoi))


## ----------------------------------------------------------------------------------------------
as.data.frame(o_aoi)[,c(5,8)]


## ---- echo = TRUE, eval=TRUE-------------------------------------------------------------------
(helm <- as.data.frame(o_aoi)[o_aoi$accuracy==2, "definition"])
b_pump_sf_ll <- st_transform(b_pump_sf, "OGC:CRS84", pipe=helm, aoi=aoi)


## ----------------------------------------------------------------------------------------------
(o_aoi1 <- sf_proj_pipelines(st_crs(b_pump_sf1), "OGC:CRS84", AOI=aoi))


## ---- echo = TRUE, eval=TRUE-------------------------------------------------------------------
b_pump_sf1_ll <- st_transform(b_pump_sf1, "OGC:CRS84")
st_distance(b_pump_sf_ll, b_pump_sf1_ll)


## ---- echo = TRUE, eval=TRUE-------------------------------------------------------------------
sf_proj_network()


## ---- echo = TRUE, eval=TRUE-------------------------------------------------------------------
Sys.setenv("PROJ_NETWORK"="ON")
sf_proj_network(TRUE)


## ---- echo = TRUE, eval=TRUE-------------------------------------------------------------------
(og <- sf_proj_pipelines(st_crs(b_pump_sf), "OGC:CRS84", AOI=aoi))


## ---- echo = TRUE, eval=TRUE-------------------------------------------------------------------
list.files(sf_proj_search_paths()[1])
b_pump_sf_llgd <- st_transform(b_pump_sf, "OGC:CRS84")
list.files(sf_proj_search_paths()[1])


## ----------------------------------------------------------------------------------------------
library(rgdal)
is_proj_CDN_enabled()
b_pump_sp_llgd <- spTransform(as(b_pump_sf, "Spatial"), "OGC:CRS84")
list.files(sf_proj_search_paths()[1])
DB <- file.path(DB0[1], "cache.db")
db <- dbConnect(SQLite(), dbname=DB)
cat(strwrap(paste(dbListTables(db), collapse=", ")), sep="\n")
dbReadTable(db, "chunks")
dbDisconnect(db)
b_pump_sf_llgdsp <- st_as_sf(b_pump_sp_llgd)


## ---- echo = TRUE, eval=TRUE-------------------------------------------------------------------
Sys.setenv("PROJ_NETWORK"="OFF")
sf_proj_network(FALSE)
c(st_distance(b_pump_sf_ll, b_pump_sf1_ll), st_distance(b_pump_sf_ll, b_pump_sf_llgd), st_distance(b_pump_sf_ll, b_pump_sf_llgdsp))


## ---- echo = TRUE, eval=TRUE-------------------------------------------------------------------
sf_use_s2(TRUE)
c(st_distance(b_pump_sf_ll, b_pump_sf1_ll), st_distance(b_pump_sf_ll, b_pump_sf_llgd), st_distance(b_pump_sf_ll, b_pump_sf_llgdsp))
sf_use_s2(FALSE)


## ----sI, echo = TRUE---------------------------------------------------------------------------
sessionInfo()

